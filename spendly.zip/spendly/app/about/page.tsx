import Doc from "@/components/Doc";
export default function About(){return <Doc title="About 🎀"><p>Spendly✨ is your wallet's brutally honest bestie.</p><p>It does quick, funny money reality-checks. It is not financial advice and it is definitely not a bank.</p><p>Made for people who check their bank balance before ordering dessert.</p></Doc>;}
