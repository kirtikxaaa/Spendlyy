"use client";
import { AnimatePresence, motion, MotionConfig } from "framer-motion";
import { useRef, useState } from "react";
import Link from "next/link";
import { GITHUB_URL } from "@/lib/config";
import { ArrowLeft } from "lucide-react";
import Hero from "@/components/Hero";
import Logo from "@/components/Logo";
import { Afford, Broke, Need, Where } from "@/components/Tools";
import { ago, useRecent } from "@/hooks/useRecent";

const TOOLS=[
 {id:"broke",e:"💀",t:"HOW BROKE AM I?",s:"Find out how financially cooked you are.",c:"#FF8FB8",tilt:-2},
 {id:"afford",e:"🛍️",t:"CAN I AFFORD THIS?",s:"Before you make a questionable purchase.",c:"#FFE68A",tilt:2},
 {id:"need",e:"🤨",t:"HOW MUCH DO I NEED THIS?",s:"Need, want, or pure delusion?",c:"#C8B6FF",tilt:-1.5},
 {id:"where",e:"🧾",t:"WHERE DID MY MONEY GO?",s:"Because ₹2,000 definitely didn't disappear by itself.",c:"#B8F2D0",tilt:1.5}] as const;

export default function Home(){
 const [tool,setTool]=useState<string|null>(null);
 const {items,add,clear}=useRecent();
 const tools=useRef<HTMLDivElement>(null);
 const cur=TOOLS.find(t=>t.id===tool);
 const Comp=tool==="broke"?Broke:tool==="afford"?Afford:tool==="need"?Need:Where;
 return <MotionConfig reducedMotion="user"><main className="mx-auto max-w-4xl pb-10">
  <AnimatePresence mode="wait">
  {!cur?<motion.div key="home" exit={{opacity:0,y:-20}}>
   <Hero onStart={()=>tools.current?.scrollIntoView({behavior:"smooth"})}/>
   <div ref={tools} className="grid gap-5 px-5 sm:grid-cols-2">{TOOLS.map((t,i)=>
    <motion.button key={t.id} onClick={()=>setTool(t.id)} initial={{opacity:0,y:40}} animate={{opacity:1,y:0}} transition={{delay:.1*i,type:"spring"}}
     whileHover={{rotate:t.tilt,y:-6}} whileTap={{scale:.96}} className="sticker p-6 text-left" style={{background:t.c}}>
     <motion.div className="text-5xl" animate={{rotate:[0,-8,8,0]}} transition={{duration:.8,repeat:Infinity,repeatDelay:4+i}} whileHover={{rotate:[0,-15,15,0]}}>{t.e}</motion.div>
     <h2 className="mt-2 font-display text-2xl font-extrabold">{t.t}</h2><p className="font-medium">{t.s}</p></motion.button>)}</div>
   <section className="mx-5 mt-10 border-t-2 border-dashed border-plum pt-5"><h2 className="font-display text-2xl font-extrabold">🧾 My Recent Chaos</h2>
    {items.length?<><ul className="mt-2 space-y-1 font-bold">{items.map(r=><li key={r.at}>{ago(r.at)} — {r.label}</li>)}</ul>
     <button onClick={clear} className="mt-2 min-h-11 underline">clear the evidence</button></>:<p className="mt-2 font-medium">Nothing yet. Your wallet is still innocent… for now.</p>}</section>
  </motion.div>:
  <motion.div key={cur.id} initial={{opacity:0,x:60}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-60}} transition={{type:"spring",stiffness:260,damping:26}} className="px-5 pt-6">
   <button onClick={()=>setTool(null)} className="mb-4 inline-flex min-h-11 items-center gap-2 font-bold"><ArrowLeft size={20}/> Back</button>
   <h1 className="mb-5 text-center font-display text-3xl font-extrabold">{cur.e} {cur.t}</h1><Comp onSave={add}/></motion.div>}
  </AnimatePresence>
  <footer className="mt-14 px-5 text-center"><div className="flex justify-center"><Logo size={44}/></div>
   <p className="font-medium">Made for people who check their bank balance before ordering dessert.</p>
   <p className="mt-2 text-sm font-bold">No bank accounts are connected. Calculations happen locally in your browser.</p>
   <p className="mt-2 flex justify-center gap-2 font-bold underline"><Link className="p-3" href="/about">About</Link><Link className="p-3" href="/privacy">Privacy</Link><a className="p-3" href={GITHUB_URL} target="_blank" rel="noreferrer">GitHub</a></p></footer>
 </main></MotionConfig>;
}
